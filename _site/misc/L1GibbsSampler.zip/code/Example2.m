%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a script to illustrade and reproduce the results in:
%
% F.Lucka, Fast MCMC sampling for sparse Bayesian inference in high-dimensional #
% inverse problems using L1-type priors, submitted to Inverse Problems,
% 2012.
%
% It reproduces the scenario described in Section 3.2.
% 
% Written by: Felix Lucka, WWU M�nster, Germany
% Email: felix.lucka@wwu.de
% Created: May 2012
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all
clc
close all

disp(['This script is about MCMC sampling in 2D using a Impulse prior with '...
    'the single component Gibbs sampler presented in:'])
disp(' ')
disp(['Lucka, F., 2012. '...
    'Fast MCMC sampling for sparse Bayesian inference in high-dimensional'...
    ' inverse problems using L1-type priors. Submitted to Inverse Problems.'])
disp(' ')
disp(['The code presented here is not the one used in the paper but '...
    'was extracted from a large toolbox for Bayesian inversion (that''s'...
    'why it looks a bit unelegant here and there). It''s not'...
    ' very comfortable and does not offers many features, but is simple to understand.'])
disp(' ')
disp('Details on the scenario used are given in Section 3.2. of the above publication.')
disp(' ')
disp('Be so kind to cite the paper if you use parts of this work.')

%% Generate the scenario (cf. Section 3.2.1)

load('2D_data','u_visu')

fig_u = figure();
axes1 = axes('Parent',fig_u,'PlotBoxAspectRatio',[1 1 1],'XTick',zeros(1,0),'YTick',zeros(1,0));
box(axes1,'on');
hold(axes1,'all');
image(u_visu,'Parent',axes1,'CDataMapping','scaled');
colormap(hot (10000));
set(axes1,'YDir','reverse')
set(axes1,'XAxisLocation','top')
xlim(axes1,[0.5 2001.5]);
ylim(axes1,[0.5 2001.5]);
colorbar('peer',axes1);
title('the real function to recover (sampled on a visulization grid)');
hold off

l = 7; % exponent of gridsize (9 was used in the paper)
n = (2^l - 1)^2

eval(['load(''2D_data'',''l' int2str(l) ''')'])
eval(['A_psf = l' int2str(l) '.A_psf;'])
eval(['m= l' int2str(l) '.m;'])
eval(['sigma = l' int2str(l) '.sigma;'])
eval(['clear l' int2str(l)])

switch l
    case 5
        lambda = 8e5   
    case 6
        lambda = 1e6
    case 7
        lambda = 3e6
    case 8
        lambda = 1e7
    case 9
        lambda = 2e7
end

% plot PSF
fig_psf = figure();
axes2 = axes('Parent',fig_psf,'PlotBoxAspectRatio',[1 1 1],'XTick',zeros(1,0),'YTick',zeros(1,0));
box(axes2,'on');
hold(axes2,'all');
imagesc(A_psf,'Parent',axes2)
set(axes2,'YDir','reverse')
set(axes2,'XAxisLocation','top')
xlim(axes2,[0.5 size(A_psf,1)+0.5]);
ylim(axes2,[0.5 size(A_psf,2)+0.5]);
title('the Gaussian point spread function');
hold off

% plot m
fig_m = figure();
axes3 = axes('Parent',fig_m,'PlotBoxAspectRatio',[1 1 1],'XTick',zeros(1,0),'YTick',zeros(1,0));
box(axes3,'on');
hold(axes3,'all');
imagesc(m,'Parent',axes3)
colormap(hot (10000));
set(axes3,'YDir','reverse')
set(axes3,'XAxisLocation','top')
xlim(axes3,[0.5 size(m,1)+0.5]);
ylim(axes3,[0.5 size(m,2)+0.5]);
title('the measurement data');
hold off


%% Generate the variable for the sampler and m_bar (cf. eq 14 and 51) and define lambda


Psi_psf = A_psf/sqrt(2*sigma^2);
Psi_tr_Psi_psf = imfilter(Psi_psf,Psi_psf,'conv');
m_bar = m/(sqrt(2) *sigma);
c_im = lambda * ones(size(m_bar));

%% Sample the posterior to compute a CM estimate


% Define sampling parameter for the single component Gibbs sampler
% cf. Section 2.3.3.

K0 = 20;
K  = 500;
% adjust to not save every sample to save memory
thinning = 1;
% 'Sys' or 'Rn' for systematic or random scan
rn_scan_fl = true;
% Number of oriented overrelaxation samples (1 for no overrelaxation)
N_O = 7;
output_fl = 1;

% sample posterior with matlab or mex file
use_mex_file = true;
if(use_mex_file)
    mex L1SamplerExample2Mexfile.F L1SamplerFunc.f90
end

tic
if(use_mex_file)
    [chain chain_indizes] = ...
        L1SamplerExample2Mexfile(Psi_psf,Psi_tr_Psi_psf,m_bar,c_im,K0,K,thinning,N_O,rn_scan_fl,output_fl);
else
    [chain chain_indizes] = ...
        L1SamplerExample2(Psi_psf,Psi_tr_Psi_psf,m_bar,c_im,K0,K,thinning,N_O,rn_scan_fl,output_fl);
end
toc


% compute CM estimate
u_CM = mean(chain,3);

% compute relative residuum 
rel_res = sqrt(sum(sum((imfilter(u_CM,A_psf,'conv') - m).^2))/sum(sum(m.^2)))

% use the same scaling as in the paper to display result
all_u = sort(u_CM(:));
min_ind = ceil(0.001*numel(all_u));
max_ind = floor(0.999*numel(all_u));
clim = [all_u(min_ind) all_u(max_ind)];
fig_u_est = figure();
axes4 = axes('Parent',fig_u_est,'PlotBoxAspectRatio',[1 1 1],'XTick',zeros(1,0),'YTick',zeros(1,0),'CLim',clim);
box(axes4,'on');
hold(axes4,'all');
imagesc(u_CM,'Parent',axes4)
colormap(hot (10000));
set(axes4,'YDir','reverse')
set(axes4,'XAxisLocation','top')
xlim(axes4,[0.5 size(m,1)+0.5]);
ylim(axes4,[0.5 size(m,2)+0.5]);
title('the estimated image');
hold off



% compute mixing plot
lpp = zeros(size(chain,3),1);
posterior_lpp = @(u_n) - 1/(2*sigma^2) * sum(sum((imfilter(u_n,A_psf,'conv') - m).^2)) - lambda *  sum(abs(u_n(:)));
for i=1:length(lpp)
    lpp(i) = posterior_lpp(chain(:,:,i));
end
figure();plot(chain_indizes,lpp,'DisplayName','mixing plot')


%% test a simple parallelization (use the same settings as above)
clear chain

try
    matlabpool open
catch exception
    matlabpool close
    matlabpool open
end
n_workers = matlabpool('size');

K_each = ceil(K/n_workers);
K_real = n_workers * K_each;

result_cell = cell(1,n_workers);

% sample posterior with matlab or mex file
use_mex_file = true;
if(use_mex_file)
    mex L1SamplerExample2Mexfile.F L1SamplerFunc.f90
end


tic
parfor ii=1:n_workers
    out_fl_here = ii==1;
    if(out_fl_here)
        disp('Display output of first worker (does not really work for the mexfiles')
    end
    if(use_mex_file)
        [result_cell{ii} ~] = ...
            L1SamplerExample2Mexfile(Psi_psf,Psi_tr_Psi_psf,m_bar,c_im,K0,K_each,thinning,N_O,rn_scan_fl,out_fl_here);
    else
        [result_cell{ii} ~] = ...
            L1SamplerExample2(Psi_psf,Psi_tr_Psi_psf,m_bar,c_im,K0,K_each,thinning,N_O,rn_scan_fl,out_fl_here);
    end
end
toc
matlabpool close

size_chains = size(result_cell{1});
chain = zeros(size_chains);
for ii=1:n_workers
    chain(1:size_chains(1),1:size_chains(2),...
        (ii-1)*size_chains(3)+1:(ii)*size_chains(3)) = result_cell{ii};
    result_cell{ii} = [];
end



% compute CM estimate
u_CM = mean(chain,3);

% compute relative residuum 
rel_res = sqrt(sum(sum((imfilter(u_CM,A_psf,'conv') - m).^2))/sum(sum(m.^2)))

% use the same scaling as in the paper to display result
all_u = sort(u_CM(:));
min_ind = ceil(0.001*numel(all_u));
max_ind = floor(0.999*numel(all_u));
clim = [all_u(min_ind) all_u(max_ind)];
fig_u_est = figure();
axes4 = axes('Parent',fig_u_est,'PlotBoxAspectRatio',[1 1 1],'XTick',zeros(1,0),'YTick',zeros(1,0),'CLim',clim);
box(axes4,'on');
hold(axes4,'all');
imagesc(u_CM,'Parent',axes4)
colormap(hot (10000));
set(axes4,'YDir','reverse')
set(axes4,'XAxisLocation','top')
xlim(axes4,[0.5 size(m,1)+0.5]);
ylim(axes4,[0.5 size(m,2)+0.5]);
title('the estimated image');
hold off
