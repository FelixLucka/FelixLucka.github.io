% L1SamplerExample2.m
%
% A version of the L1 sampler that is fitted to the script Example2.m 
%
% This code is based on:
%
% F.Lucka, Fast MCMC sampling for sparse Bayesian inference in high-dimensional #
% inverse problems using L1-type priors, submitted to Inverse Problems,
% 2012.
%
% Usage:  [zhi_chain zhi_chain_indizes] = ...
%    L1SamplerExample2(Psi_psf,Psi_tr_Psi_psf,m_bar,c_im,K0,K,thinning,N_O,rn_scan_fl,out_fl)
%
% Input:
%
% Psi_psf   - Transformed point spread function of the forward mapping Psi,
%             size is (m x n)
% Psi_tr_Psi_psf   - Transformed point spread function of the Psi' * Psi
%             size is (m x n)
% m_bar     - Transformed measurement image data, size (m x n) (cf. eq 13 in the paper)
% c_im      - Image containg the c coefficients, size (m x n) (cf. eq 16 in the paper)
% K0        - Number of burn-in steps
% K         - Number of real samples
% thinning  - sub sampling rate of the chain to reduce the memory usage
% N_O       - Number of samples for oriented overrelaxaion (see Section 2.3.3. in the paper) 
% rn_scan_fl- true if random scanning should be used ("RnGibbs" in the
%             paper) and false if systematic scanning should be used ("SysGibbs" in the
%             paper
% out_fl    - true, if output should be displayed 
%       
% Output:
%
% zhi_chain         - A 3D array of size size (m x n x floor(K/thinning),
%                     containing the sampled images
% zhi_chain_indizes - The indizes of the samples in zhi_chain
%
% Written by: Felix Lucka, WWU M�nster, Germany
% Email: felix.lucka@wwu.de
% Created: May 2012


function [zhi_chain zhi_chain_indizes] = ...
    L1SamplerExample2(Psi_psf,Psi_tr_Psi_psf,m_bar,c_im,K0,K,thinning,N_O,rn_scan_fl,out_fl)



[m n] = size(Psi_psf);
dof = n*m; % total number of degrees of freedom (n in the paper)


% make Psi_tr_Psi_psf symmetric again
Psi_tr_Psi_psf = (Psi_tr_Psi_psf+Psi_tr_Psi_psf')/2;
% Cut off too small values
cut_off = eps * max(abs(Psi_psf(:)));
Psi_psf(abs(Psi_psf) < cut_off) = 0;
Psi_tr_Psi_psf(abs(Psi_tr_Psi_psf) < cut_off) = 0;

zhi = zeros(m,n);

% Use ordered overrelaxation ?
OOR_fl = N_O > 1;
if(OOR_fl)
    if(mod(N_O,2)~= 1)
        error('N_O has to be odd!')
    end
end


% allocate chains
zhi_chain = zeros(m,n,floor((K+K0)/thinning)-floor(K0/thinning));
zhi_chain_indizes = zeros(1,floor((K+K0)/thinning)-floor(K0/thinning));
chain_index = 1;

% Initialize some stuff for the sampling

[aux_ind1 aux_ind2] =  find(Psi_psf);
x_min = min(aux_ind1);
x_max = max(aux_ind1);
y_min = min(aux_ind2);
y_max = max(aux_ind2);
Psi_psf_cut = Psi_psf(x_min:x_max,y_min:y_max);
kernel_length_Psi = size(Psi_psf_cut);
x_ind_Psi = 0:1:kernel_length_Psi(1)-1;
y_ind_Psi = 0:1:kernel_length_Psi(2)-1;

[aux_ind1 aux_ind2] =  find(Psi_tr_Psi_psf);
x_min = min(aux_ind1);
x_max = max(aux_ind1);
y_min = min(aux_ind2);
y_max = max(aux_ind2);
Psi_tr_Psi_psf_cut = Psi_tr_Psi_psf(x_min:x_max,y_min:y_max);
kernel_length_Psi_tr_Psi = size(Psi_tr_Psi_psf_cut);
x_os_Psi_tr_Psi = floor(kernel_length_Psi_tr_Psi(1)/2);
y_os_Psi_tr_Psi = floor(kernel_length_Psi_tr_Psi(2)/2);
x_ind_Psi_tr_Psi = 0:1:kernel_length_Psi_tr_Psi(1)-1;
y_ind_Psi_tr_Psi = 0:1:kernel_length_Psi_tr_Psi(2)-1;

psi_norm = zeros(m,n);
Psi_i_m_bar = zeros(m,n);
template = padarray(ones(m,n),floor(kernel_length_Psi/2));
m_bar_pad = padarray(m_bar,floor(kernel_length_Psi/2));

for i=1:m
    for j=1:n
        psi_norm(i,j) = sum(sum((template(i+x_ind_Psi,j+y_ind_Psi).* Psi_psf_cut).^2));
        Psi_i_m_bar(i,j) = sum(sum((m_bar_pad(i+x_ind_Psi,j+y_ind_Psi).* Psi_psf_cut)));
    end
end
clear template m_bar_pad


all_sqrt_a = sqrt(psi_norm);
zhi_pad = padarray(zhi,floor(kernel_length_Psi_tr_Psi/2));





[sub_indizes_x sub_indizes_y] = ind2sub([m,n],1:dof);


% precompute some constants
log_2 = log(2);
log_pi = log(pi);


%%% The sampling starts!

% display some output
if(out_fl)
    if(OOR_fl)
        if(rn_scan_fl)
            fprintf('Compute CM estimate via L1 single component Gibbs sampler using random scanning and ordered overrelaxation with N_O = %d.',N_O)
        else
            fprintf('Compute CM estimate via L1 single component Gibbs sampler using systematic scanning and ordered overrelaxation with N_O = %d.',N_O)
        end
    else
        if(rn_scan_fl)
            fprintf('Compute CM estimate via L1 single component Gibbs sampler using random scanning.')
        else
            fprintf('Compute CM estimate via L1 single component Gibbs sampler using systematic scanning.')
        end
    end
    
    fprintf('Full status bar for comparison:\n')
    next_output_step = floor((K+K0)/min(100,(K+K0)));
    for j=1:(K+K0)
        if(j == next_output_step)
            fprintf('.')
            next_output_step = next_output_step + floor((K+K0)/min(100,(K+K0)));
        end
    end
    next_output_step = floor((K+K0)/min(100,(K+K0)));
    fprintf('\nCurrent status bar:\n')
end

% now it really starts

for j=1:(K+K0)
    
    if(rn_scan_fl)
        rand_comp_ind = randi(dof,dof,1);
    end
    
    for i=1:dof
        
        if(rn_scan_fl)
            i_comp = rand_comp_ind(i);
        else
            i_comp = i;
        end
        
        
        if(psi_norm(i_comp) > 0)
            
            i_comp_sub = sub_indizes_x(i_comp);
            j_comp_sub = sub_indizes_y(i_comp);
            
            sqrt_a = all_sqrt_a(i_comp);
            
            b = sum(sum((zhi_pad(i_comp_sub+x_ind_Psi_tr_Psi,j_comp_sub+y_ind_Psi_tr_Psi).* Psi_tr_Psi_psf_cut)));
            b =  2 * (Psi_i_m_bar(i_comp) - b  + psi_norm(i_comp) * zhi(i_comp));
            
            c = c_im(i_comp);
            
            % draw from exp(-a*x^2+b*x+c*abs(x)) via inverse cumulative
            % distibution method
            
            % determine alpha_+ and alpha_-
            alpha_plus = (b+c)/(2*sqrt_a);
            alpha_minus = (-b+c)/(2*sqrt_a);
            
            % dependent on the case, use different fomula, since c > 0, it
            % is not possible that both alpha_+ and alpha_- are negative
            
            %%% the easy case, use fomua 1 %%%
            if(alpha_plus > 0 && alpha_minus > 0)
                gamma = erfcx(alpha_plus) + erfcx(alpha_minus);
                
                % Draw a new random number in [0,1]
                if(OOR_fl) % Use oriented over relaxation
                    % Compute current probability
                    if(zhi(i_comp) < 0)
                        log_curr_prob = -sqrt_a * zhi(i_comp) * (sqrt_a * zhi(i_comp) - 2 * alpha_plus) + ...
                            log(erfcx(- sqrt_a * zhi(i_comp) + alpha_plus)) - log(gamma);
                        curr_prob = exp(log_curr_prob);
                    else
                        log_res_curr_prob = -sqrt_a * zhi(i_comp) * (sqrt_a * zhi(i_comp) + 2 * alpha_minus) + ...
                            + log(erfcx(sqrt_a * zhi(i_comp) + alpha_minus)) - log(gamma);
                        curr_prob = 1 - exp(log_res_curr_prob);
                    end
                    % over relax curr_prob w.r.t.  uniform distribution on
                    % [0,1] and N_O
                    probs = rand(N_O,1);
                    probs = [probs;curr_prob];
                    [probs_s s_ind] = sort(probs);
                    [~,s_ind_inv] = sort(s_ind);
                    pos_curr = s_ind_inv(N_O +1);
                    drawn_prob = probs_s(N_O + 2 - pos_curr);
                else % normal Gibbs sampler
                    drawn_prob = rand();
                end
                
                %%. Part 1, check left side of distribution
                u = log(drawn_prob) - alpha_plus^2 + log(gamma);
                if(u < -680 && abs(log(alpha_plus)) > 3)
                    % use approximation : http://dlmf.nist.gov/7.17
                    theta = - log_pi - log(-u);
                    v = (-theta - 2);
                    w = 2/(theta - 2 * u);
                    a2 = 0.125 * v;
                    a3 = - 0.03125 * (v^2 + 6*v - 6);
                    a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                    z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                elseif(abs(log(alpha_plus)) > 3)
                    z = erfcinv(exp(u));
                else
                    z = erfcinv(drawn_prob * exp(-alpha_plus^2) * gamma);
                end
                y = -(z - alpha_plus)/sqrt_a;
                %%. Part 2, check right side of distribution if y > 0
                if(y > 0)
                    u = log(1-drawn_prob) - alpha_minus^2 + log(gamma);
                    if(u < -680 && abs(log(alpha_minus)) > 3)
                        % use approximation : http://dlmf.nist.gov/7.17
                        theta = - log_pi - log(-u);
                        v = (-theta - 2);
                        w = 2/(theta - 2 * u);
                        a2 = 0.125 * v;
                        a3 = - 0.03125 * (v^2 + 6*v - 6);
                        a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                        z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                    elseif(abs(log(alpha_minus)) > 3)
                        z = erfcinv(exp(u));
                    else
                        z = erfcinv((1-drawn_prob) * exp(-alpha_minus^2) * gamma);
                    end
                    y =  (z - alpha_minus)/sqrt_a;
                end
                
                %%% use fomula 2 %%%
            elseif(alpha_plus < 0)
                minus_erfcx_plus= erfcx(-alpha_plus);
                erfcx_minus = erfcx(alpha_minus);
                gamma = minus_erfcx_plus - erfcx_minus;
                
                % Draw a new random number in [0,1]
                if(OOR_fl) % Use oriented over relaxation
                    % Compute current probability
                    if(zhi(i_comp) < 0)
                        arg_erfcx = - sqrt_a * zhi(i_comp) + alpha_plus;
                        if(arg_erfcx > 0)
                            log_curr_prob = - arg_erfcx^2 + log(erfcx(arg_erfcx)) - log_2 - ...
                                log(1 - sign(gamma) * exp( -alpha_plus^2 + log(abs(gamma)) - log_2));
                        else
                            log_curr_prob =  log(1 - exp(log(erfcx(-arg_erfcx)) - log_2 - arg_erfcx^2))  ...
                                - log(1 - sign(gamma) * exp( -alpha_plus^2 + log(abs(gamma)) - log_2));
                        end
                        curr_prob = exp(log_curr_prob);
                    else
                        arg_erfcx = sqrt_a * zhi(i_comp) + alpha_minus;
                        if(arg_erfcx > 0)
                            log_res_curr_prob = - arg_erfcx^2 + log(erfcx(arg_erfcx)) - log_2 - (b*c)/sqrt_a^2 - ...
                                log(1 - sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 - (b*c)/sqrt_a^2));
                        else
                            log_res_curr_prob = log(1 - exp(log(erfcx(-arg_erfcx)) -...
                                log_2 - arg_erfcx^2)) - (b*c)/sqrt_a^2 - ...
                                log(1 - sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 - (b*c)/sqrt_a^2));
                        end
                        curr_prob = 1 - exp(log_res_curr_prob);
                    end
                    % over relax curr_prob w.r.t.  uniform distribution on
                    % [0,1] and N_O
                    probs = rand(N_O,1);
                    probs = [probs;curr_prob];
                    [probs_s s_ind] = sort(probs);
                    [~,s_ind_inv] = sort(s_ind);
                    pos_curr = s_ind_inv(N_O +1);
                    drawn_prob = probs_s(N_O + 2 - pos_curr);
                else % normal Gibbs sampler
                    drawn_prob = rand();
                end
                
                %%. Part 1, check left side of distribution
                u = log(drawn_prob) + log_2 + ...
                    log(1 - sign(gamma) * exp( -alpha_plus^2 + log(abs(gamma)) - log_2));
                if(u < -680 && abs(log(-alpha_plus)) > 3)
                    % use approximation : http://dlmf.nist.gov/7.17
                    theta = - log_pi - log(-u);
                    v = (-theta - 2);
                    w = 2/(theta - 2 * u);
                    a2 = 0.125 * v;
                    a3 = - 0.03125 * (v^2 + 6*v - 6);
                    a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                    z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                elseif(abs(log(-alpha_plus)) > 3)
                    z = erfcinv(exp(u));
                else
                    z = erfcinv(2*drawn_prob - drawn_prob * exp(-alpha_plus^2) * gamma);
                end
                y = -(z - alpha_plus)/sqrt_a;
                %%. Part 2, check right side of distribution if y > 0
                if(y > 0)
                    u = log(1-drawn_prob) + log_2 + (b*c)/sqrt_a^2 + ...
                        log(1 - sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 - (b*c)/sqrt_a^2));
                    if(u < -680 && max(abs(log([-alpha_plus,alpha_minus]))) > 3)
                        % use approximation : http://dlmf.nist.gov/7.17
                        theta = - log_pi - log(-u);
                        v = (-theta - 2);
                        w = 2/(theta - 2 * u);
                        a2 = 0.125 * v;
                        a3 = - 0.03125 * (v^2 + 6*v - 6);
                        a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                        z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                    elseif(max(abs(log([-alpha_plus,alpha_minus]))) > 3)
                        z = erfcinv(exp(u));
                    else
                        z = erfcinv((1-drawn_prob) * (2*exp((b*c)/sqrt_a^2)  - exp(-alpha_minus^2) * gamma));
                    end
                    y =  (z - alpha_minus)/sqrt_a;
                end
                
                %%% now alpha_minus is < 0, use fomula 3 %%%
            else
                erfcx_plus = erfcx(alpha_plus);
                minus_erfcx_minus = erfcx(-alpha_minus);
                gamma = erfcx_plus - minus_erfcx_minus;
                
                % Draw a new random number in [0,1]
                if(OOR_fl) % Use oriented over relaxation
                    % Compute current probability
                    if(zhi(i_comp) < 0)
                        log_curr_prob = - (-sqrt_a * zhi(i_comp) + alpha_plus)^2 + ...
                            log(erfcx(-sqrt_a * zhi(i_comp) + alpha_plus)) - log_2 + (b*c)/sqrt_a^2 - ...
                            log(1 + sign(gamma) * exp(-alpha_plus^2 + log(abs(gamma)) - log_2 + (b*c)/sqrt_a^2 ));
                        curr_prob = exp(log_curr_prob);
                    else
                        arg_erfcx = sqrt_a * zhi(i_comp) + alpha_minus;
                        if(arg_erfcx > 0)
                            log_res_curr_prob = - arg_erfcx^2 + log(erfcx(arg_erfcx)) - log_2  - ...
                                log(1 + sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 ));
                        else
                            log_res_curr_prob = log(1 - exp(log(erfcx(-arg_erfcx)) -...
                                log_2 - arg_erfcx^2))  - ...
                                log(1 + sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 ));
                        end
                        curr_prob = 1 - exp(log_res_curr_prob);
                    end
                    % over relax curr_prob w.r.t.  uniform distribution on
                    % [0,1] and N_O
                    probs = rand(N_O,1);
                    probs = [probs;curr_prob];
                    [probs_s s_ind] = sort(probs);
                    [~,s_ind_inv] = sort(s_ind);
                    pos_curr = s_ind_inv(N_O +1);
                    drawn_prob = probs_s(N_O + 2 - pos_curr);
                else % normal Gibbs sampler
                    drawn_prob = rand();
                end
                
                %%. Part 1, check left side of distribution
                u = log(drawn_prob) + log_2 - (b*c)/sqrt_a^2 + ...
                    log(1 + sign(gamma) * exp(-alpha_plus^2 + log(abs(gamma)) - log_2 + (b*c)/sqrt_a^2 ));
                if(u < -680 && max(abs(log([alpha_plus,-alpha_minus]))) > 3)
                    % use approximation : http://dlmf.nist.gov/7.17
                    theta = - log_pi - log(-u);
                    v = (-theta - 2);
                    w = 2/(theta - 2 * u);
                    a2 = 0.125 * v;
                    a3 = - 0.03125 * (v^2 + 6*v - 6);
                    a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                    z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                elseif(max(abs(log([alpha_plus,-alpha_minus]))) > 3)
                    z = erfcinv(exp(u));
                else
                    z = erfcinv(drawn_prob * (2 * exp(-(b*c)/sqrt_a^2) + exp(-alpha_plus^2) * gamma ));
                end
                y = -(z - alpha_plus)/sqrt_a;
                %%. Part 2, check right side of distribution if y > 0
                if(y > 0)
                    u = log(1-drawn_prob) + log_2 + ...
                        log(1 + sign(gamma) * exp( -alpha_minus^2 + log(abs(gamma)) - log_2));
                    if(u < -680 && abs(log(-alpha_minus)) > 3)
                        % use approximation : http://dlmf.nist.gov/7.17
                        theta = - log_pi - log(-u);
                        v = (-theta - 2);
                        w = 2/(theta - 2 * u);
                        a2 = 0.125 * v;
                        a3 = - 0.03125 * (v^2 + 6*v - 6);
                        a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                        z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                    elseif(abs(log(-alpha_minus)) > 3)
                        z = erfcinv(exp(u));
                    else
                        z = erfcinv((1-drawn_prob)*(2 +  exp(-alpha_minus^2) * gamma));
                    end
                    y =  (z - alpha_minus)/sqrt_a;
                end
                
            end
            
        else
            % if no likelyhood term is present, just draw from the two
            % sided exponential distribution by inverse cumulative
            % distribution method.
            if(OOR_fl)
                y_array = sign(randn(N_O,1)) .* 1/c_im(i_comp) .* log(rand(N_O,1));
                y_array(N_O +1 ,1) = zhi(i_comp);
                [y_s s_ind] = sort(y_array);
                [~,s_ind_inv] = sort(s_ind);
                pos_curr = s_ind_inv(N_O +1);
                y = y_s(N_O + 2 - pos_curr);
            else
                y = sign(randn()) * 1/c_im(i_comp) * log(rand());
            end
        end
        zhi(i_comp) = y;
        zhi_pad(i_comp_sub+x_os_Psi_tr_Psi,j_comp_sub+y_os_Psi_tr_Psi) = y;
    end
    
    % Store current state
    if(j > K0 && mod(j,thinning) == 0)
        zhi_chain(:,:,chain_index) = zhi;
        zhi_chain_indizes(chain_index) = j;
        chain_index = chain_index + 1;
    end
    
    % print some output
    if(out_fl && j == next_output_step)
        fprintf('.')
        next_output_step = next_output_step + floor((K+K0)/min(100,(K+K0)));
    end
end
if(out_fl)
    fprintf('\n')
end


end
