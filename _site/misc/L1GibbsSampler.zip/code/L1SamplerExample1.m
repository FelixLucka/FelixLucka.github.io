% L1SamplerExample1.m
%
% A version of the L1 sampler that is fitted to the script Example1.m
%
% This code is based on:
%
% F.Lucka, Fast MCMC sampling for sparse Bayesian inference in high-dimensional #
% inverse problems using L1-type priors, submitted to Inverse Problems,
% 2012.
%
% Usage:  [zhi_chain zhi_chain_indizes] = L1SamplerExample1(Psi,m_bar,c_vec,K0,K,thinning,N_O,rn_scan_fl,chain_fun)
%
% Input:
%
% Psi       - Transformed system matrix of size (k x n) (cf. eq 13 in the paper)
% m_bar     - Transformed measurement data (cf. eq 13 in the paper)
% c_vec     - Vector containg the c coefficients (cf. eq 16 in the paper)
% K0        - Number of burn-in steps
% K         - Number of real samples
% thinning  - sub sampling rate of the chain to reduce the memory usage
% N_O       - Number of samples for oriented overrelaxaion (see Section 2.3.3. in the paper)
% rn_scan_fl- true if random scanning should be used ("RnGibbs" in the
%             paper) and false if systematic scanning should be used ("SysGibbs" in the
%             paper
% chain_fun - Mapping applied to the samples.
%             If chain_fun is a scalar, no mapping is applied and the whole sample is stored.
%             If chain_fun is a n-dim vector, the dot product of each sample with this vector is stored.
%
% Output:
%
% zhi_chain         - A matrix with floor(K/thinning) columns, each column contains a sample
% zhi_chain_indizes - The indizes of the samples in zhi_chain
%
% Written by: Felix Lucka, WWU M�nster, Germany
% Email: felix.lucka@wwu.de
% Created: May 2012

function [zhi_chain zhi_chain_indizes] = ...
    L1SamplerExample1(Psi,m_bar,c_vec,K0,K,thinning,N_O,rn_scan_fl,chain_fun)


n = size(Psi,2);
zhi = zeros(n,1);

% if chain_fun is 1, store every state, if it is a vector of size n,
% project every state onto it

if(isequal(chain_fun,1))
    fun_fl = false;
    dim_chain = n;
elseif(length(chain_fun) == n)
    fun_fl = true;
    project_v = chain_fun;
    dim_chain = 1;
else
    error('invalid value for sample_para.chain_fun')
end


% Use ordered overrelaxation ?
OOR_fl = N_O > 1;
if(OOR_fl)
    if(mod(N_O,2)~= 1)
        error('N_O has to be odd!')
    end
end


% allocate chains
zhi_chain = zeros(dim_chain,floor((K+K0)/thinning)-floor(K0/thinning));
zhi_chain_indizes = zeros(1,floor((K+K0)/thinning)-floor(K0/thinning));
chain_index = 1;


% Initialize some stuff for the sampling (cf. Section 2.3.3.)

psi_norm = zeros(n,1);
for i=1:n
    psi_norm(i) = Psi(:,i)' * Psi(:,i);
end
all_sqrt_a = sqrt(psi_norm);

Psi_i_m_bar = zeros(n,1);
for i=1:n
    Psi_i_m_bar(i) = Psi(:,i)' * m_bar;
end

% the number of unknowns up to which Phi is build and used (cf. eq 19)
n_max_Phi_impl = 20000;
n_max_fl = n < n_max_Phi_impl;
if(n_max_fl)
    Psi_t_Psi = Psi'*Psi;
    clear Psi
end

% precompute some constants
log_2 = log(2);
log_pi = log(pi);


%%% The sampling starts!

% display some output
if(OOR_fl)
    if(rn_scan_fl)
        fprintf('Compute CM estimate via L1 single component Gibbs sampler using random scanning and ordered overrelaxation with N_O = %d.\n',N_O)
    else
        fprintf('Compute CM estimate via L1 single component Gibbs sampler using systematic scanning and ordered overrelaxation with N_O = %d.\n',N_O)
    end
else
    if(rn_scan_fl)
        fprintf('Compute CM estimate via L1 single component Gibbs sampler using random scanning.\n')
    else
        fprintf('Compute CM estimate via L1 single component Gibbs sampler using systematic scanning.\n')
    end
end

fprintf('Full status bar for comparison:\n')
next_output_step = floor((K+K0)/min(100,(K+K0)));
for j=1:(K+K0)
    if(j == next_output_step)
        fprintf('.')
        next_output_step = next_output_step + floor((K+K0)/min(100,(K+K0)));
    end
end
next_output_step = floor((K+K0)/min(100,(K+K0)));
fprintf('\nCurrent status bar:\n')

% now it really starts

for j=1:(K+K0)
    
    if(rn_scan_fl)
        rand_comp_ind = randi(n,n,1);
    end
    
    for i=1:n
        
        if(rn_scan_fl)
            i_comp = rand_comp_ind(i);
        else
            i_comp = i;
        end
        
        
        if(psi_norm(i_comp) > 0)
            
            sqrt_a = all_sqrt_a(i_comp);
            
            if(n_max_fl)
                b =  2 * (Psi_i_m_bar(i_comp) - zhi' * Psi_t_Psi(:,i_comp) + psi_norm(i_comp) * zhi(i_comp));
            else
                b =  2 * (Psi_i_m_bar(i_comp) -  (Psi(:,i_comp)' * Psi) * zhi + psi_norm(i_comp) * zhi(i_comp));
            end
            c = c_vec(i_comp);
            
            % draw from exp(-a*x^2+b*x+c*abs(x)) via inverse cumulative
            % distibution method
            % the code is a bit long, one could make it way shorter by
            % summarising certain parts in subfunctions...however, that is
            % slow in Matlab
            
            % determine alpha_+ and alpha_-
            alpha_plus = (b+c)/(2*sqrt_a);
            alpha_minus = (-b+c)/(2*sqrt_a);
            
            % dependent on the case, use different fomula, since c > 0, it
            % is not possible that both alpha_+ and alpha_- are negative
            
            %%% the easy case, use fomua 1 %%%
            if(alpha_plus > 0 && alpha_minus > 0)
                gamma = erfcx(alpha_plus) + erfcx(alpha_minus);
                
                % Draw a new random number in [0,1]
                if(OOR_fl) % Use oriented over relaxation
                    % Compute current probability
                    if(zhi(i_comp) < 0)
                        log_curr_prob = -sqrt_a * zhi(i_comp) * (sqrt_a * zhi(i_comp) - 2 * alpha_plus) + ...
                            log(erfcx(- sqrt_a * zhi(i_comp) + alpha_plus)) - log(gamma);
                        curr_prob = exp(log_curr_prob);
                    else
                        log_res_curr_prob = -sqrt_a * zhi(i_comp) * (sqrt_a * zhi(i_comp) + 2 * alpha_minus) + ...
                            + log(erfcx(sqrt_a * zhi(i_comp) + alpha_minus)) - log(gamma);
                        curr_prob = 1 - exp(log_res_curr_prob);
                    end
                    % over relax curr_prob w.r.t.  uniform distribution on
                    % [0,1] and N_O
                    probs = rand(N_O,1);
                    probs = [probs;curr_prob];
                    [probs_s s_ind] = sort(probs);
                    [~,s_ind_inv] = sort(s_ind);
                    pos_curr = s_ind_inv(N_O +1);
                    drawn_prob = probs_s(N_O + 2 - pos_curr);
                else % normal Gibbs sampler
                    drawn_prob = rand();
                end
                
                %%. Part 1, check left side of distribution
                u = log(drawn_prob) - alpha_plus^2 + log(gamma);
                if(u < -680 && abs(log(alpha_plus)) > 3)
                    % use approximation : http://dlmf.nist.gov/7.17
                    theta = - log_pi - log(-u);
                    v = (-theta - 2);
                    w = 2/(theta - 2 * u);
                    a2 = 0.125 * v;
                    a3 = - 0.03125 * (v^2 + 6*v - 6);
                    a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                    z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                elseif(abs(log(alpha_plus)) > 3)
                    z = erfcinv(exp(u));
                else
                    z = erfcinv(drawn_prob * exp(-alpha_plus^2) * gamma);
                end
                y = -(z - alpha_plus)/sqrt_a;
                %%. Part 2, check right side of distribution if y > 0
                if(y > 0)
                    u = log(1-drawn_prob) - alpha_minus^2 + log(gamma);
                    if(u < -680 && abs(log(alpha_minus)) > 3)
                        % use approximation : http://dlmf.nist.gov/7.17
                        theta = - log_pi - log(-u);
                        v = (-theta - 2);
                        w = 2/(theta - 2 * u);
                        a2 = 0.125 * v;
                        a3 = - 0.03125 * (v^2 + 6*v - 6);
                        a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                        z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                    elseif(abs(log(alpha_minus)) > 3)
                        z = erfcinv(exp(u));
                    else
                        z = erfcinv((1-drawn_prob) * exp(-alpha_minus^2) * gamma);
                    end
                    y =  (z - alpha_minus)/sqrt_a;
                end
                
                %%% use fomula 2 %%%
            elseif(alpha_plus < 0)
                minus_erfcx_plus= erfcx(-alpha_plus);
                erfcx_minus = erfcx(alpha_minus);
                gamma = minus_erfcx_plus - erfcx_minus;
                
                % Draw a new random number in [0,1]
                if(OOR_fl) % Use oriented over relaxation
                    % Compute current probability
                    if(zhi(i_comp) < 0)
                        arg_erfcx = - sqrt_a * zhi(i_comp) + alpha_plus;
                        if(arg_erfcx > 0)
                            log_curr_prob = - arg_erfcx^2 + log(erfcx(arg_erfcx)) - log_2 - ...
                                log(1 - sign(gamma) * exp( -alpha_plus^2 + log(abs(gamma)) - log_2));
                        else
                            log_curr_prob =  log(1 - exp(log(erfcx(-arg_erfcx)) - log_2 - arg_erfcx^2))  ...
                                - log(1 - sign(gamma) * exp( -alpha_plus^2 + log(abs(gamma)) - log_2));
                        end
                        curr_prob = exp(log_curr_prob);
                    else
                        arg_erfcx = sqrt_a * zhi(i_comp) + alpha_minus;
                        if(arg_erfcx > 0)
                            log_res_curr_prob = - arg_erfcx^2 + log(erfcx(arg_erfcx)) - log_2 - (b*c)/sqrt_a^2 - ...
                                log(1 - sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 - (b*c)/sqrt_a^2));
                        else
                            log_res_curr_prob = log(1 - exp(log(erfcx(-arg_erfcx)) -...
                                log_2 - arg_erfcx^2)) - (b*c)/sqrt_a^2 - ...
                                log(1 - sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 - (b*c)/sqrt_a^2));
                        end
                        curr_prob = 1 - exp(log_res_curr_prob);
                    end
                    % over relax curr_prob w.r.t.  uniform distribution on
                    % [0,1] and N_O
                    probs = rand(N_O,1);
                    probs = [probs;curr_prob];
                    [probs_s s_ind] = sort(probs);
                    [~,s_ind_inv] = sort(s_ind);
                    pos_curr = s_ind_inv(N_O +1);
                    drawn_prob = probs_s(N_O + 2 - pos_curr);
                else % normal Gibbs sampler
                    drawn_prob = rand();
                end
                
                %%. Part 1, check left side of distribution
                u = log(drawn_prob) + log_2 + ...
                    log(1 - sign(gamma) * exp( -alpha_plus^2 + log(abs(gamma)) - log_2));
                if(u < -680 && abs(log(-alpha_plus)) > 3)
                    % use approximation : http://dlmf.nist.gov/7.17
                    theta = - log_pi - log(-u);
                    v = (-theta - 2);
                    w = 2/(theta - 2 * u);
                    a2 = 0.125 * v;
                    a3 = - 0.03125 * (v^2 + 6*v - 6);
                    a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                    z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                elseif(abs(log(-alpha_plus)) > 3)
                    z = erfcinv(exp(u));
                else
                    z = erfcinv(2*drawn_prob - drawn_prob * exp(-alpha_plus^2) * gamma);
                end
                y = -(z - alpha_plus)/sqrt_a;
                %%. Part 2, check right side of distribution if y > 0
                if(y > 0)
                    u = log(1-drawn_prob) + log_2 + (b*c)/sqrt_a^2 + ...
                        log(1 - sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 - (b*c)/sqrt_a^2));
                    if(u < -680 && max(abs(log([-alpha_plus,alpha_minus]))) > 3)
                        % use approximation : http://dlmf.nist.gov/7.17
                        theta = - log_pi - log(-u);
                        v = (-theta - 2);
                        w = 2/(theta - 2 * u);
                        a2 = 0.125 * v;
                        a3 = - 0.03125 * (v^2 + 6*v - 6);
                        a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                        z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                    elseif(max(abs(log([-alpha_plus,alpha_minus]))) > 3)
                        z = erfcinv(exp(u));
                    else
                        z = erfcinv((1-drawn_prob) * (2*exp((b*c)/sqrt_a^2)  - exp(-alpha_minus^2) * gamma));
                    end
                    y =  (z - alpha_minus)/sqrt_a;
                end
                
                %%% now alpha_minus is < 0, use fomula 3 %%%
            else
                erfcx_plus = erfcx(alpha_plus);
                minus_erfcx_minus = erfcx(-alpha_minus);
                gamma = erfcx_plus - minus_erfcx_minus;
                
                % Draw a new random number in [0,1]
                if(OOR_fl) % Use oriented over relaxation
                    % Compute current probability
                    if(zhi(i_comp) < 0)
                        log_curr_prob = - (-sqrt_a * zhi(i_comp) + alpha_plus)^2 + ...
                            log(erfcx(-sqrt_a * zhi(i_comp) + alpha_plus)) - log_2 + (b*c)/sqrt_a^2 - ...
                            log(1 + sign(gamma) * exp(-alpha_plus^2 + log(abs(gamma)) - log_2 + (b*c)/sqrt_a^2 ));
                        curr_prob = exp(log_curr_prob);
                    else
                        arg_erfcx = sqrt_a * zhi(i_comp) + alpha_minus;
                        if(arg_erfcx > 0)
                            log_res_curr_prob = - arg_erfcx^2 + log(erfcx(arg_erfcx)) - log_2  - ...
                                log(1 + sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 ));
                        else
                            log_res_curr_prob = log(1 - exp(log(erfcx(-arg_erfcx)) -...
                                log_2 - arg_erfcx^2))  - ...
                                log(1 + sign(gamma) * exp(-alpha_minus^2 + log(abs(gamma)) - log_2 ));
                        end
                        curr_prob = 1 - exp(log_res_curr_prob);
                    end
                    % over relax curr_prob w.r.t.  uniform distribution on
                    % [0,1] and N_O
                    probs = rand(N_O,1);
                    probs = [probs;curr_prob];
                    [probs_s s_ind] = sort(probs);
                    [~,s_ind_inv] = sort(s_ind);
                    pos_curr = s_ind_inv(N_O +1);
                    drawn_prob = probs_s(N_O + 2 - pos_curr);
                else % normal Gibbs sampler
                    drawn_prob = rand();
                end
                
                %%. Part 1, check left side of distribution
                u = log(drawn_prob) + log_2 - (b*c)/sqrt_a^2 + ...
                    log(1 + sign(gamma) * exp(-alpha_plus^2 + log(abs(gamma)) - log_2 + (b*c)/sqrt_a^2 ));
                if(u < -680 && max(abs(log([alpha_plus,-alpha_minus]))) > 3)
                    % use approximation : http://dlmf.nist.gov/7.17
                    theta = - log_pi - log(-u);
                    v = (-theta - 2);
                    w = 2/(theta - 2 * u);
                    a2 = 0.125 * v;
                    a3 = - 0.03125 * (v^2 + 6*v - 6);
                    a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                    z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                elseif(max(abs(log([alpha_plus,-alpha_minus]))) > 3)
                    z = erfcinv(exp(u));
                else
                    z = erfcinv(drawn_prob * (2 * exp(-(b*c)/sqrt_a^2) + exp(-alpha_plus^2) * gamma ));
                end
                y = -(z - alpha_plus)/sqrt_a;
                %%. Part 2, check right side of distribution if y > 0
                if(y > 0)
                    u = log(1-drawn_prob) + log_2 + ...
                        log(1 + sign(gamma) * exp( -alpha_minus^2 + log(abs(gamma)) - log_2));
                    if(u < -680 && abs(log(-alpha_minus)) > 3)
                        % use approximation : http://dlmf.nist.gov/7.17
                        theta = - log_pi - log(-u);
                        v = (-theta - 2);
                        w = 2/(theta - 2 * u);
                        a2 = 0.125 * v;
                        a3 = - 0.03125 * (v^2 + 6*v - 6);
                        a4 = 1/384 * (4*v^3 + 27*v^2 + 108*v - 300);
                        z = 1/sqrt(w) + a2 * w^(3/2) + a3 * w^(5/2) + a4 * w^(7/2);
                    elseif(abs(log(-alpha_minus)) > 3)
                        z = erfcinv(exp(u));
                    else
                        z = erfcinv((1-drawn_prob)*(2 +  exp(-alpha_minus^2) * gamma));
                    end
                    y =  (z - alpha_minus)/sqrt_a;
                end
                
            end
            
        else
            % if no likelyhood term is present, just draw from the two
            % sided exponential distribution by inverse cumulative
            % distribution method.
            if(OOR_fl)
                y_array = sign(rand(N_O,1)-0.5) .* log(rand(N_O,1))/c_vec(i_comp);
                y_array(N_O +1 ,1) = zhi(i_comp);
                [y_s s_ind] = sort(y_array);
                [~,s_ind_inv] = sort(s_ind);
                pos_curr = s_ind_inv(N_O +1);
                y = y_s(N_O + 2 - pos_curr);
            else
                y = sign(rand()-0.5) * log(rand())/c_vec(i_comp);
            end
        end
        
        zhi(i_comp) = y;
    end
    
    % Store current state
    if(j > K0 && mod(j,thinning) == 0)
        if(fun_fl)
            zhi_chain(chain_index) = sum(project_v .* zhi);
        else
            zhi_chain(:,chain_index) = zhi;
        end
        zhi_chain_indizes(chain_index) = j;
        chain_index = chain_index + 1;
    end
    
    % print status output
    if(j == next_output_step)
        fprintf('.')
        next_output_step = next_output_step + floor((K+K0)/min(100,(K+K0)));
    end
end
fprintf('\n')

end
