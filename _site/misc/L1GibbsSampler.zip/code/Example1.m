%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a script to illustrade and reproduce the results in:
%
% F.Lucka, Fast MCMC sampling for sparse Bayesian inference in high-dimensional #
% inverse problems using L1-type priors, submitted to Inverse Problems,
% 2012.
%
% It reproduces the scenario described in Section 3.1.
% 
% Written by: Felix Lucka, WWU M�nster, Germany
% Email: felix.lucka@wwu.de
% Created: May 2012
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all
clc
close all

disp(['This script is about MCMC sampling in 1D using a TV prior with '...
    'the single component Gibbs sampler presented in:'])
disp(' ')
disp(['Lucka, F., 2012. '...
    'Fast MCMC sampling for sparse Bayesian inference in high-dimensional'...
    ' inverse problems using L1-type priors. Submitted to Inverse Problems.'])
disp(' ')
disp('The scenario is similar to the one used in Lassas & Siltanen, 2004')
disp(' ')
disp(['The code presented here is not the one used in the paper but '...
    'was extracted from a large toolbox for Bayesian inversion (that''s'...
    ' why it looks a bit unelegant here and there). It''s not'...
    ' very comfortable and does not offers many features, but is simple to understand.'])
disp(' ')
disp('Details on the scenario used are given in Section 3.1. of the above publication.')
disp(' ')
disp('Be so kind to cite the papers if you use parts of this work.')

%% Generate the scenario (cf. Section 3.1.1)

% the real function that has to be recovered
u = @(x) (x > 1/3) & (x < 2/3);
x_visu = 0:0.001:1;
figure();
plot(x_visu,u(x_visu),'DisplayName','the real function to recover')
ylim([-0.1,1.1])

% define the data grid
L_m = 5;
k = 2^L_m -2
% the data_grid is made up by the boundaries of the intervals over which
% the integration takes part
data_grid = 1/(k+2):(1/(k+2)):(k+1)/(k+2);

% generate measurement data (cf. eq 27)
RandStream.setDefaultStream(RandStream('mt19937ar','seed',123));
sigma = 0.001;
m = zeros(k,1);
for i = 1:k
    m(i) = quad(u,data_grid(i),data_grid(i+1)) + sigma * randn();
end
figure(); bar((data_grid(1:end-1)+data_grid(2:end))/2,m,...
    'DisplayName','the measurement data')

% define the solution grid
L_u = 6;
n = 2^L_u - 1
delta_t = 1/(n+1);
source_grid = delta_t:delta_t:(1-delta_t);

% build A (cf. eq 28)
A = zeros(k,n);
L_diff = L_u - L_m;
for j=1:k
    A(j,(j*2^(L_diff)):((j+1)*2^(L_diff))) = delta_t;
    A(j,j*2^(L_diff))  = 0.5 * A(j,j*2^(L_diff));
    A(j,((j+1)*2^(L_diff)))  = 0.5 * A(j,((j+1)*2^(L_diff))) ;
end

% regularization parameter lambda, choose a scaling that leads to the
% convergence of the CM estimate

lambda = 25 * sqrt(n+1)

%% Generate the transformed system matrix Phi and m_bar (cf. eq 13) and define lambda

% build V explicitly or use faster and less memory consuming method?
explicit_fl = false;

if(explicit_fl)
    V = zeros(n,n);
    for i=1:n
        for j=1:n
            V(i,j) = (i >= j); %(cf. eq 31)
        end
    end
    Psi = (A * V)/(sqrt(2) *sigma);
else % better if n is big
    Psi = A/sqrt(2*sigma^2);
    Psi = cumsum(Psi,2);
    Psi = Psi(size(A,1):-1:1,:);
    Psi = Psi(:,n:-1:1);
end

m_bar = m/(sqrt(2) *sigma);


%(cf. eq 16)
c_vec = lambda * ones(n,1);
c_vec(1) = 0;

%% Sample the posterior

% Define sampling parameter for the single component Gibbs sampler
% cf. Section 2.3.3.

K0 = 500;
K  = 50000;
% adjust to not save every sample to save memory
thinning = 1; 
% 'Sys' or 'Rn' for systematic or random scan
rn_scan_fl = true; 
% Number of oriented overrelaxation samples (1 for no overrelaxation)
N_O = 1; 
% do not apply any function to the samples but store the raw states (see next cell) 
chain_fun = 1; 


% sample posterior with matlab or mex file
use_mex_file = false;
if(use_mex_file)
    mex L1SamplerExample1Mexfile.F L1SamplerFunc.f90
end

tic
if(use_mex_file)
[chain chain_indizes] = ...
    L1SamplerExample1Mexfile(Psi,m_bar,c_vec,K0,K,thinning,N_O,rn_scan_fl,chain_fun);  
else 
[chain chain_indizes] = ...
    L1SamplerExample1(Psi,m_bar,c_vec,K0,K,thinning,N_O,rn_scan_fl,chain_fun);
end
toc

% transform back from zhi to u (zhi are the increments):
chain = cumsum(chain,1);

% compute CM estimate
u_CM = mean(chain,2);

% compute relative residuum 
rel_res = sqrt(sum((A*u_CM - m).^2)/sum(m.^2))

% plot u_CM
figure();
plot(x_visu,u(x_visu),'DisplayName','CM estimate','Color',[1 0 0]);
ylim([-0.1,1.1])
hold on
plot([0,source_grid,1],[u_CM(1);u_CM;u_CM(end)]);
hold off

% compute mixing plot
lpp = zeros(size(chain,2),1);
posterior_lpp = @(u_n) - 1/(2*sigma^2) * sum(sum((A * u_n - m).^2)) - lambda *  sum(abs(diff(u_n))); 
for i=1:length(lpp)
    lpp(i) = posterior_lpp(chain(:,i));
end
figure();
plot(chain_indizes,lpp,'DisplayName','mixing plot')

% compute first eigenvector of covariance matrix
% to get the right one, K has to be very large...
cov_mat = cov(chain');
[cov_mat_eig_vec,cov_mat_eig_val] = eigs(cov_mat,1);

%% Sample the posterior to compute the autocorrelation function



K0 = 500;
K  = 500000;
rn_scan_fl = true; 
N_O = 7; 
% project each sample onto the first eigenvector of the covariance matrix
chain_fun = cov_mat_eig_vec; 


% sample posterior with matlab or mex file
use_mex_file = true;
if(use_mex_file)
    mex L1SamplerExample1Mexfile.F L1SamplerFunc.f90
end


tic
if(use_mex_file)
[chain chain_indizes] = ...
    L1SamplerExample1Mexfile(Psi,m_bar,c_vec,K0,K,1,N_O,rn_scan_fl,chain_fun);  
else 
[chain chain_indizes] = ...
    L1SamplerExample1(Psi,m_bar,c_vec,K0,K,1,N_O,rn_scan_fl,chain_fun);
end
toc


R = xcorr(chain(:)-mean(chain),'coeff');
R = R(length(chain):end);

disp(' ')
disp(['For smooth, monoton and strictly positive autocorrelation plots, you'...
    ' need to draw a huge number of samples (the plots in the paper resulted'...
    ' from many hours of computation).'])

cut_off = 5000;
figure();plot(chain_indizes(1:5000)-chain_indizes(1),R(1:cut_off))

